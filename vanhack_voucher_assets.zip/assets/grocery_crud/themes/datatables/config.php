<?php
$config['crud_paging'] 			= false;